import { getStore } from '@netlify/blobs';
import { timingSafeEqual } from 'node:crypto';

export const config = { path: '/api/replies' };
const json = (body, status = 200) => Response.json(body, {
  status, headers: {'Cache-Control': 'no-store'}
});

function isAdmin(request) {
  const key = process.env.ADMIN_KEY;
  if (!key) return false;
  const expected = Buffer.from('Bearer ' + key);
  const provided = Buffer.from(request.headers.get('Authorization') ?? '');
  return expected.length === provided.length && timingSafeEqual(expected, provided);
}

export default async function replies(request) {
  if (request.method === 'GET') {
    if (!isAdmin(request)) return json({error: 'unauthorized'}, 401);
    const store = getStore({name: 'hajin-rsvp', consistency: 'strong'});
    const {blobs} = await store.list();
    const records = await Promise.all(blobs.map(({key}) => store.get(key, {type: 'json'})));
    return json(records.filter(Boolean).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)));
  }

  if (request.method !== 'POST') return json({error: 'method'}, 405);
  if (request.headers.get('Origin') !== new URL(request.url).origin) return json({error: 'origin'}, 403);
  let data;
  try { data = await request.json(); } catch { return json({error: 'invalid'}, 400); }
  const {id, status, guests} = data ?? {};
  const name = typeof data?.name === 'string' ? data.name.trim() : '';
  if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/.test(id) || !name || name.length > 40 ||
      !['yes', 'no', 'maybe'].includes(status) || !Number.isInteger(guests) ||
      (status === 'yes' ? guests < 1 || guests > 18 : guests !== 0)) return json({error: 'invalid'}, 400);

  const store = getStore({name: 'hajin-rsvp', consistency: 'strong'});
  await store.setJSON(id, {name, status, guests, updatedAt: new Date().toISOString()});
  return json({saved: true});
}
